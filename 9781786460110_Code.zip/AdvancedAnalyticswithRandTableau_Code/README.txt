Chapter 1 does not contain codes
Chapter 2 contains codes
Chapter 3 contains codes
Chapter 4 contains codes
Chapter 5 contains codes
Chapter 6 contains codes
Chapter 7 contains codes
Chapter 8 contains codes

Tableau does not require Coding